import 'package:flutter/material.dart';
//import 'package:google_maps_flutter/google_maps_flutter.dart';
//import 'dart:async';

class MapWidget extends StatelessWidget {
  const MapWidget(this.title, this.message);
  
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(child: Column(
      children: <Widget>[
        Text(title),
        Text(message),
      ],
    ),
    );
    // return MaterialApp(
    //   debugShowCheckedModeBanner: false,
      //home: Maps(),
    //);
  }
}

// class Maps extends StatefulWidget {
//   @override
//   _MapsState createState() => _MapsState();
// }

// class _MapsState extends State<Maps> {  
    
//   Completer<GoogleMapController> _controller = Completer();
//   @override
//     Widget build(BuildContext context) {
//       return MaterialApp(
//         home: Scaffold(
//         body: GoogleMap(
//                 initialCameraPosition: CameraPosition(
//                   target: LatLng(27.712020, 85.312950),
//                   //target: LatLng(lati, lang),
//                   zoom: 10,
//                 ),
//                 mapType: MapType.hybrid,
//                   onMapCreated: (GoogleMapController controller){
//                     _controller.complete(controller);
//                   },
//                 ),
                
//               ),
    
    
//           );
//          }
    

// }
